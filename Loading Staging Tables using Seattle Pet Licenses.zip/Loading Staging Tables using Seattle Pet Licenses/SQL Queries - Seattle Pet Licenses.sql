USE poc
GO
--To display the Record and Row Counts
SELECT * FROM stg_seattle_pet_license

--To display the Information Schema 
SELECT * FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = 'stg_seattle_pet_license';

EXEC sp_help 'dbo.stg_seattle_pet_license'




